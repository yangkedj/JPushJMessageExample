package cn.jpush.im.android.demo.Listener;

public interface OnChangedListener {
	abstract void OnChanged(int id, boolean CheckState);
}